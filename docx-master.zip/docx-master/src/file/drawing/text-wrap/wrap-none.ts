// http://officeopenxml.com/drwPicFloating-textWrap.php
import { XmlComponent } from "@file/xml-components";

export class WrapNone extends XmlComponent {
    public constructor() {
        super("wp:wrapNone");
    }
}
