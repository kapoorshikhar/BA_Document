import { XmlComponent } from "@file/xml-components";

export class SourceRectangle extends XmlComponent {
    public constructor() {
        super("a:srcRect");
    }
}
