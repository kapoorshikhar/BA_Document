// http://officeopenxml.com/drwSp-prstGeom.php
import { XmlComponent } from "@file/xml-components";

export class AdjustmentValues extends XmlComponent {
    public constructor() {
        super("a:avLst");
    }
}
