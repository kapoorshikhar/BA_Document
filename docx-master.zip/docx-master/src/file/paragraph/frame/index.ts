export * from "./frame-properties";
